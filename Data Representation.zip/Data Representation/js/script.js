/**
Metacritic Vs Player

this project looks at the data of meta critic review scores vs player review scores
main menu has the option to look at general stats or to look at the stats in a game by game basis 
*/

"use strict";

//timer for animations 
let savedTime; 
let frameTime = 45;
let passedTime;
let count;

//CSV data and array of said data
let table;
let points = []; // game objects

// arrays for the data representation A
let userScores = []; 
let metaScores = [];

let page = 0; // page on list
let tempScore = 0; //for data rep A
let clicked = 0;
let tempMeta;
let tempPlayer;


//sounds 
let SMonkey;
let SDrums;
let OK;
let crow;
let sadCrow;
let ya;
let good;
let golf;
let bad;
let monkey;

//images
let stickA;
let stickB;
let br;
let bl;
let ar;
let al;
let rockL;
let paperL;
let scissorL;
let rockR;
let paperR;
let scissorR;
let rockRd;
let rockLd;


//Which menu screen are we on
let menuScreen;

function preload() 
{
  //sounds 
  SMonkey = loadSound('assets/sounds/Monkey - Sound Effect.wav');
  SDrums = loadSound('assets/sounds/Drum Roll - Sound Effect (HD).wav');
  OK = loadSound('assets/sounds/OK.wav');
  crow = loadSound('assets/sounds/Crow.wav');
  sadCrow = loadSound('assets/sounds/sadCrow.wav');
  ya = loadSound('assets/sounds/ya.wav');
  good = loadSound('assets/sounds/good.wav');
  golf = loadSound('assets/sounds/golf.wav');
  bad = loadSound('assets/sounds/badEnding.wav');
  monkey = loadSound('assets/sounds/Monkey - Sound Effect.wav');

  //images
  stickB = loadImage('assets/images/stickmanB.png');
  stickA = loadImage('assets/images/stickmanA.png');
  ar = loadImage('assets/images/stickmanAr.png');
  al = loadImage('assets/images/stickmanAl.png');
  br = loadImage('assets/images/stickmanBr.png');
  bl = loadImage('assets/images/stickmanBl.png');

  rockL = loadImage('assets/images/rockL.png');
  paperL = loadImage('assets/images/paperL.png');
  scissorL = loadImage('assets/images/scissorL.png');
  rockR = loadImage('assets/images/rockR.png');
  paperR = loadImage('assets/images/paperR.png');
  scissorR = loadImage('assets/images/scissorR.png');
  rockRd = loadImage('assets/images/rockRd.png');
  rockLd = loadImage('assets/images/rockLd.png');



  //table
  table = loadTable("gameScores.csv", "csv", "header");
 }
 
function setup() 
{

  savedTime = millis();
  count = 0;


  createCanvas(1400, 1000);
  //colorMode(HSB);
  menuScreen = 0;

  imageMode(CENTER);

  for (var r = 0; r < table.getRowCount(); r++)// Cycle through each row of the table
  { 
    points[r] = new gameData(table.getString(r, 0),
    table.getString(r, 1),
    table.getString(r, 2),
    table.getString(r, 3),
    table.getString(r, 4),
    table.getString(r, 5));
    }
   
}

function draw()
{

  
  switch(menuScreen)
  {
    case 0:
      {
        background(0);
        menu();
        break;
      }
      
    case 1:
      {
        background(0);
        games();
        break;
      }
    case 2:
      {
        dataRepA();
        break;
      }
    case 3:
      {
        
        dataRepB(tempMeta,tempPlayer);
        break;
      }
    case 4: //displaying data onto screen
      {
        let userAverage = 0;
        let metaAverage = 0;
        let difference = 0;
        for(let i = 0; i<points.length;i++) //calculate average scores for all games
        {
          userAverage = userAverage + points[i].user;
          metaAverage = metaAverage + int(points[i].meta);
          
          if((points[i].meta - points[i].user)<0)
          {
            difference = difference - (points[i].meta - points[i].user);
          }
          else
          {
            difference = difference + (points[i].meta - points[i].user);
          }  
        }

        userAverage = userAverage/points.length;
        metaAverage = metaAverage/points.length;
        difference = difference/points.length;
        
        background(115, 203, 209);
        textSize(50);
        fill(255);
        text('Stats', width/2, 250);
        textSize(25);
        text("Average User Rating: " + userAverage +"%",width/2,400);
        text("Average Metacritic Rating: " + metaAverage +"%",width/2,500);
        text("Average Difference in Score: " + difference +"%",width/2,600);

        rect(225, 850, 100, 50);
        textSize(15);
        fill(0);
        text("Back",275,880);
        break;
      }  
      


  }  


}

function mousePressed()
{
  let r = round(random(0,1));
  switch(menuScreen)
  {
    case 0: // main menu
      {
        if(mouseX >=550 && mouseX <=810 && mouseY >=445 && mouseY <= 520) //games list
        menuScreen = 1;
        else if(mouseX >=550 && mouseX <=810 && mouseY >=595 && mouseY <= 670) //stats
        menuScreen = 4;
        break;
      }
      
    case 1: // games list
      {
        if(mouseX >=950 && mouseX <=1050 && mouseY >=750 && mouseY <= 800) // back
        page -= 12;
        else if(mouseX >=1075 && mouseX <=1175 && mouseY >=750 && mouseY <= 800) //next
        page += 12;
        else if(mouseX >=250 && mouseX <=350 && mouseY >=750 && mouseY <= 800) //menu
        menuScreen = 0;


        else if(mouseX >=225 && mouseX <=675 && mouseY >=170 && mouseY <= 230) // game 1
        {
          if (r == 0)
          {
            tempMeta = points[0+page].meta;
            tempPlayer = points[0+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(0+page);
        }
        else if(mouseX >=225 && mouseX <=675 && mouseY >=270 && mouseY <= 330) // game 2
        {
          if (r == 0)
          {
            tempMeta = points[1+page].meta;
            tempPlayer = points[1+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(1+page);
        }
        else if(mouseX >=225 && mouseX <=675 && mouseY >=370 && mouseY <= 430) // game 3
        {
          if (r == 0)
          {
            tempMeta = points[2+page].meta;
            tempPlayer = points[2+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(2+page);
        }
        else if(mouseX >=225 && mouseX <=675 && mouseY >=470 && mouseY <= 530) // game 4
        {
          if (r == 0)
          {
            tempMeta = points[3+page].meta;
            tempPlayer = points[3+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(3+page);
        }
        else if(mouseX >=225 && mouseX <=675 && mouseY >=570 && mouseY <= 630) // game 5
        {
          if (r == 0)
          {
            tempMeta = points[4+page].meta;
            tempPlayer = points[4+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(4+page);
        }
        else if(mouseX >=225 && mouseX <=675 && mouseY >=670 && mouseY <= 730) // game 6
        {
          if (r == 0)
          {
            tempMeta = points[5+page].meta;
            tempPlayer = points[5+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(5+page);
        }
        else if(mouseX >=725 && mouseX <=1175 && mouseY >=170 && mouseY <= 230) // game 7
        {
          if (r == 0)
          {
            tempMeta = points[6+page].meta;
            tempPlayer = points[6+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(6+page);
        }
        else if(mouseX >=725 && mouseX <=1175 && mouseY >=270 && mouseY <= 330) // game 8
        {
          if (r == 0)
          {
            tempMeta = points[7+page].meta;
            tempPlayer = points[7+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(7+page);
        }
        else if(mouseX >=725 && mouseX <=1175 && mouseY >=370 && mouseY <= 430) // game 9
        {
          if (r == 0)
          {
            tempMeta = points[8+page].meta;
            tempPlayer = points[8+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(8+page);
        }
        else if(mouseX >=725 && mouseX <=1175 && mouseY >=470 && mouseY <= 530) // game 10
        {
          if (r == 0)
          {
            tempMeta = points[9+page].meta;
            tempPlayer = points[9+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(9+page);
        }
        else if(mouseX >=725 && mouseX <=1175 && mouseY >=570 && mouseY <= 630) // game 11
        {
          if (r == 0)
          {
            tempMeta = points[10+page].meta;
            tempPlayer = points[10+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(10+page);
        }
        else if(mouseX >=725 && mouseX <=1175 && mouseY >=670 && mouseY <= 730) // game 12
        {
          if (r == 0)
          {
            tempMeta = points[11+page].meta;
            tempPlayer = points[11+page].user;
            background(115, 203, 209);
            count = 0;
            menuScreen=3;
            golf.play();
          }
          else
          dataRepASetup(11+page);
        }    
        
        break;
      }
    case 21:
      {
        if(mouseX >=250 && mouseX <=350 && mouseY >=850 && mouseY <= 900) //menu
        menuScreen = 1;
        break;
      } 
    case 31:
      {
        if(mouseX >=250 && mouseX <=350 && mouseY >=850 && mouseY <= 900) //menu
        menuScreen = 1;
        break;
      }
    case 4:
      {
        if(mouseX >=250 && mouseX <=350 && mouseY >=850 && mouseY <= 900) //menu
        menuScreen = 0;
        break;
      }         
     

  }
}

function games() //list of games 
{
  if (page < 0)
  page = 573;
  if (page > 573)
  page = 0;
  
  background(115, 203, 209);
  fill(0, 100, 200);

  rect(225, 170, 450, 50);  rect(725, 170, 450, 50);
  rect(225, 270, 450, 50);  rect(725, 270, 450, 50);
  rect(225, 370, 450, 50);  rect(725, 370, 450, 50);
  rect(225, 470, 450, 50);  rect(725, 470, 450, 50);
  rect(225, 570, 450, 50);  rect(725, 570, 450, 50);
  rect(225, 670, 450, 50);  rect(725, 670, 450, 50);

  textSize(55)
  text("Games",width/2,125);
  textSize(15)
  fill(255);
  textAlign(CENTER);
  text(points[0+page].name, 450, 200); text(points[6+page].name, 950, 200);
  text(points[1+page].name, 450, 300); text(points[7+page].name, 950, 300);
  text(points[2+page].name, 450, 400); text(points[8+page].name, 950, 400);
  text(points[3+page].name, 450, 500); text(points[9+page].name, 950, 500);
  text(points[4+page].name, 450, 600); text(points[10+page].name, 950, 600);
  text(points[5+page].name, 450, 700); text(points[11+page].name, 950, 700);
 

  rect(950, 750, 100, 50); //back
  rect(1075, 750, 100, 50); //next
  rect(225, 750, 100, 50); //menu

  fill(0);
  text("Next",1125,780);
  text("Back",1000,780);
  text("Menu",275,780);


  

}

function menu() //main menu
{
  background(115, 203, 209);
  fill(255);
  rect(550, 595, 310, 75);
  fill(255);
  rect(550, 445, 310, 75);
  textSize(50)
  text('Metacritic Score vs Player Score', width/2, 250);
  fill(0);
  textAlign(CENTER);
  text('GAMES', width/2, 500);
  text('STATS', width/2, 650);
  textSize(26);
  
}

function calculate(a,b) // calculates how accurate the game score was
{
  if(a-b>=-10 && a-b<=10) //if the score is accurate
  return 1;
  else if(a-b>=-15 && a-b<=15) //if the score is somewhat accurate
  return 2;
  else if(a-b>=-30 && a-b<=30) //if the score is not accurate
  return 3;
  else //if the score was review bombed
  return 4;
}

function averageGenerator(score,position) //makes a random set of numbers that average to the game score 
{
  let value;
  do
  {
    value = ceil(random(1,100)); //makes a random score from 0 - 100

  }
  while(floor(((score-value)/(19-position)) <= 100) != true && score-value>0)
  tempScore = floor(score-value);
  return value;
}

function dataRepASetup(gameIndex) //sets up the stickmans for the data representation A
{
  
  clicked = 0;
  tempScore = (points[gameIndex].user)*20;
  for(let i = 0; i<20; i++) //for user score
  {
    let end = averageGenerator(tempScore,i);
    userScores[i] = new stickmanA(end,points[gameIndex].user);
  }

  tempScore = (points[gameIndex].meta)*20;
  for(let j = 0; j<20; j++) //for meta score
  {
    let end = averageGenerator(tempScore,j);
    metaScores[j] = new stickmanB(end,points[gameIndex].meta);
  }
  
  menuScreen = 2;
  savedTime = millis();
  SDrums.play();
  ya.play();

}

function dataRepA()
{

  passedTime = millis() - savedTime;
  

  if(passedTime >= frameTime)
  {

    background(115, 203, 209);

    strokeWeight(3);
    
    textAlign(CENTER);
    textSize(15)
    fill(255);

    noStroke();

    text("Player Score",width/2,200);
    text("Metacritic Score",width/2,800);
    text("0",200,270); text("20",400,270); text("40",600,270); text("60",800,270); text("80",1000,270); text("100",1200,270);
    text("0",200,740); text("20",400,740); text("40",600,740); text("60",800,740); text("80",1000,740); text("100",1200,740);
    
    stroke(0);
    
    line(200,700,1200,700); //lines for average score
    line(200,300,1200,300);
 
    line(200,725,200,675);
    line(1200,725,1200,675);

    line(400,725,400,675); line(600,725,600,675); line(800,725,800,675); line(1000,725,1000,675); 
    

    line(200,325,200,275);
    line(1200,325,1200,275);
    
    line(400,325,400,275); line(600,325,600,275); line(800,325,800,275); line(1000,325,1000,275);
   


    for(let j = 0; j<20; j++) //move stickman A
    {
      userScores[j].move(count);

    }
    for(let k = 0; k<20; k++) // move stickman B
    {
      metaScores[k].move(count);
    }

    savedTime = millis();

    if (count >= 79) //if stickmen are done animating
    {
      count = 0;
      noStroke();

      for(let i =0; i<100; i++) //make dotted lines representing their average score
      {
      fill(100,0,0,90);
      circle(map(metaScores[count].realScore,0,100,200,1200),i*10,5);
      fill(0,0,100,90);
      circle(map(userScores[count].realScore,0,100,200,1200),i*10,5);
      }

      let result = calculate(metaScores[count].realScore,userScores[count].realScore); //calulate how accurate it was 
      switch(result)
      {
        case 1:
          {
            good.play();
            textSize(60);
            fill(33, 196, 69);
            text("Accurate!",width/2,height/2);
            fill(255);
            rect(225, 850, 100, 50);
            textSize(15);
            fill(0);
            text("Back",275,880);
            break;
          }
        case 2:
          {
            OK.play();
            textSize(60);
            fill(137, 33, 196);
            text("Close Enough.",width/2,height/2);
            fill(255);
            rect(225, 850, 100, 50);
            textSize(15);
            fill(0);
            text("Back",275,880);
            break;
          }
        case 3:
          {
            crow.play();
            textSize(60);
            fill(196, 120, 33);
            text("Not Accurate!",width/2,height/2);
            fill(255);
            rect(225, 850, 100, 50);
            textSize(15);
            fill(0);
            text("Back",275,880);
            break;
          }   
        case 4:
          {
            sadCrow.play();
            textSize(60);
            fill(54,6,6);
            text("Review Bombed",width/2,height/2);
            fill(255);
            rect(225, 850, 100, 50);
            textSize(15);
            fill(0);
            text("Back",275,880);
            break;
          }   
      }
      menuScreen = 21;
    }
    else
    {
      count++;
    } 
    savedTime = millis();
  }

  
}

function dataRepB(m,p)
{
  
  passedTime = millis() - savedTime;

  if(passedTime >= 290 || (count>4 && passedTime >= 90)) //rock paper scissors animation timer
  {
    background(115, 203, 209);
    if (count<=4)
    {
      if(count %2 == 0)
      {
        image(rockL,500,400);
        image(rockR,900,400);
      }
      else
      {
        image(rockLd,500,450);
        image(rockRd,900,450);
      }
    }
    else
    {
      let r = round(random(0,2));
      
      let result = calculate(m,p); //calulate how accurate it was 
      switch(result)
      {
        case 1:
          {
            good.play();
            textSize(60);
            fill(33, 196, 69);
            text("Accurate!",width/2,200);
            fill(255);
            rect(225, 850, 100, 50);
            textSize(15);
            fill(0);
            text("Back",275,880);
            
            if(r == 0) //random wining animation
            {
              image(paperL,500,500);
              image(scissorR,900,500);
            }
            else if(r == 1)
            {
              image(scissorL,500,500);
              image(rockRd,900,500);
            }
            else if(r == 2)
            {
              image(rockLd,500,500);
              image(paperR,900,500);
            }

            break;
          }
        case 2:
          {
            monkey.play();
            textSize(60);
            fill(137, 33, 196);
            text("Close Enough.",width/2,200);
            fill(255);
            rect(225, 850, 100, 50);
            textSize(15);
            fill(0);
            text("Back",275,880);
            if(r == 0) // random tie animation
            {
              image(paperL,500,500);
              image(paperR,900,500);
            }
            else if(r == 1)
            {
              image(scissorL,500,500);
              image(scissorR,900,500);
            }
            else if(r == 2)
            {
              image(rockLd,500,500);
              image(rockRd,900,500);
            }
            break;
          }
        case 3:
          {
            bad.play();
            textSize(60);
            fill(196, 120, 33);
            text("Not Accurate!",width/2,200);
            fill(255);
            rect(225, 850, 100, 50);
            textSize(15);
            fill(0);
            text("Back",275,880);
            if(r == 0) //random loose animation
            {
              image(scissorL,500,500);
              image(paperR,900,500);
            }
            else if(r == 1)
            {
              image(rockLd,500,500);
              image(scissorR,900,500);
            }
            else if(r == 2)
            {
              image(paperL,500,500);
              image(rockRd,900,500);
            }
            break;
          }   
        case 4:
          {
            sadCrow.play();
            textSize(60);
            fill(54,6,6);
            text("Review Bombed",width/2,200);
            fill(255);
            rect(225, 850, 100, 50);
            textSize(15);
            fill(0);
            text("Back",275,880);
            if(r == 0) //chaos
            {
              image(paperR,500,500);
              image(scissorL,900,500);
            }
            else if(r == 1)
            {
              image(scissorR,500,500);
              image(rockLd,900,500);
            }
            else if(r == 2)
            {
              image(rockRd,500,500);
              image(paperL,900,500);
            }
            break;
            
          }  
        }     

      menuScreen = 31
    }
    savedTime = millis();
    count++;
  }
  


}

class stickmanA //user stickmen
{
  constructor(end,realScore)
  {
    this.start = random(50,1350);
    this.end = map(end,0,100,200,1200);
    this.icon = stickA;
    this.x = this.start;
    this.y = 50;
    this.yin = 50+random(-25,25);
    this.realScore = realScore;
    
  }

  move(pos)
  {
    this.pos = pos
    this.x = map(this.pos,0,80,this.start,this.end);
    this.y = map(this.pos,0,80,this.yin,300);

    if(pos == 0 || pos >=79)
    {
      this.icon = stickA;
    }
    else if(pos%2 == 0)
    {
      this.icon = ar;
    }
    else
    {
      this.icon = al;
    }

    image(this.icon,this.x,this.y,30,30);
  }

}

class stickmanB //meta critic stickmen
{
  constructor(end,realScore)
  {
    this.start = random(50,1350);
    this.end = map(end,0,100,200,1180);
    this.icon = stickB;
    this.x = this.start;
    this.yin = 900+random(-25,25);
    this.y = 900;
    this.realScore = realScore;
  }

  move(pos)
  {
    this.pos = pos
    this.x = map(this.pos,0,80,this.start,this.end); //map position so they go towards their spot in line
    this.y = map(this.pos,0,80,this.yin,695);

    if(pos == 0 || pos >=79) //walking 'animation'
    {
      this.icon = stickB;
    }
    else if(pos%2 == 0)
    {
      this.icon = br;
    }
    else
    {
      this.icon = bl;
    }
    image(this.icon,this.x,this.y,45,35);
 
  
  }
}

class gameData
{
  constructor(name,console,release,summary,meta,user)
  {
    this.name = name;
    this.console = console;
    this.release = release;
    this.summary = summary;
    this.meta = meta;
    this.user = user*10;
  }


}