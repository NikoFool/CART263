/**
Shadows Follow Slow
Niko Leduc

Particle assignment 
*/

"use strict";

let song;

function preload() 
{

  song = loadSound('assets/sounds/Untitled v1.wav');

}

let tree = []; // Arrays for different particle types 
let shadow = [];
let eyes =[];

function setup() 
{
createCanvas(1920, 950);

let numTree = random(16,25);
let treeGap = width/numTree;
let numShadows = ceil(random(3,floor(numTree/5))); 
let shadowX = [];
let treeX = [];
song.play();

 // *****************************make tree particles**********************************************
for(let j=0; j < numTree; j++) 
 {

  let yBottom = random(-175,25); // makes random top and bottom for trees to group in
  let yTop = random(-10,45);
  let xRand = random(-20, 20);
  treeX[j] = (j*treeGap)+xRand+25;
  print(treeX[j]+ "treeX");

  for(let i = 0; i < 75; i++) 
  {
    let b = false;
    if(i%4==0) //make black every 4 beziers
    {
    b = true;
    }
    let w = (j*10)+i
    tree[w] = new Trees(j+1,b,yBottom,yTop,xRand,treeGap);
  }
} 

 // *****************************make shadow particles*******************************************


for(let i=0; i<= numShadows; i++)
{
  let r; //random number
  
  print(floor(random(0,treeX.length)));
  let match = false; //checker for tree match
   r = treeX[floor(random(0,treeX.length-1))]; //make equal to random tree

  print("r "+r);
  shadowX[i] = r; //set shadows cordinate to r

  for(let j=0; j<3; j++)
  {
    shadow[i] = new Shadows(shadowX[i],j); //make new shadow particle (3 parts)
  }

} 

noFill();
}
function draw() 
{
 background(150);

 fill(140);
 stroke(140);
 ellipse(width/2, height, width+400, 450); //ground

 stroke(0);
 fill(0);
 for(let i = 0; i < shadow.length; i++)
 {
  shadow[i].move(12);
 }
 for(let i = 0; i < tree.length; i++) //draw trees
 {
  tree[i].move();
  
 }
 for(let i = 0; i < shadow.length; i++)
 {
  shadow[i].move(3);
 }
}

//***************************************************Particles**********************************
class Trees { //bezier particles 

 constructor(group,black,yBottom,yTop,xRandom,treeGap) 
 {
//print(group + 'a');
 this.mapGroup = (treeGap*group)+xRandom;
 this.x1 = (random(0,45))+this.mapGroup;
 this.y1 =  yTop;
 this.x2 = (random(0,55))+this.mapGroup;
 this.y2 = height + yBottom;
 this.xA = this.x1+10
 this.xB = this.x2-10
 this.yA = this.y2/3
 this.yB = this.y2/3*2

 if(black == true)
  this.c = 50;
 else 
  this.c = color(120, 105, 104);
 this.group = group


 }
 move() 
 {
  stroke(this.c);
  strokeWeight(13);
  noFill();
  //fill(242, 229, 179);

  if(mouseX < this.mapGroup+150 && mouseX > this.mapGroup-150)
  {
    this.yA = map(mouseY, this.y1, this.y2/2+this.y1, this.y1+25, this.y2/2+this.y1-25,true); //y bounds for the top bezier curve
    this.xA = map(mouseX, this.x1-100, this.x1+100, this.x1-10, this.x1+10); //x bounds for top bezier curve
  
    this.yB = map(mouseY, this.y2/2+this.y1, this.y2,this.y2/2+this.y1-25, this.y2+25,true); //y bounds for the bottom bezier curve
    this.xB = map(mouseX, this.x1-100, this.x1+100, this.x1+10, this.x1-10); //x bounds for bottom bezier curve
  }
  
      
  bezier(this.x1, this.y1, this.xA, this.yA, this.xB, this.yB, this.x2, this.y2);
  
 }
}

class Shadows { //

  constructor(x,part) 
  {
    print("made"+x);
    this.x = x;
    this.part = part;
    this.size = random(1,3);
    
  }
  move(part) 
  {
   stroke(0);
   fill(0);
   if(part == 12)
    {
    
      triangle(this.x,740,this.x-55,725,this.x,675);
      triangle(this.x,780,this.x-25,755,this.x,695);
    }
    else
    {
      triangle(this.x,790,this.x-35,770,this.x,800);
    }
    
   
  }
 }


