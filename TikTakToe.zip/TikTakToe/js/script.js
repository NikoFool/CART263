/*
TikTakToe
Niko Leduc
Student ID: 40255923
A game of tiktaktoe
*/


let gameBoard = [];
let screen;
let pTurn;
let p1Score = 0;
let p2Score = 0;
let turnCount;

function setup() 
{
  turnCount =0;
  pTurn = 1;
  rectMode(CENTER);
  screen =0;
  createCanvas(400, 600);
  
  for(let i=0; i<3; i++) //sets 2d array (board) to be equal to 0's
    {
      gameBoard[i] = [];
      for(let j=0; j<3; j++)
        {
          gameBoard[i][j] = 0;
        }
    }
  
}

function draw() 
{
  
  
  switch(screen) //display set screen
    {
      case 0:
        {
          mainMenu();
          break;
        }
      case 1:
        {
          background(220);
          board();
          break;
        }
      case 2:
        {
          
        }
    }

  
  
  
}

function mousePressed()
{

  switch(screen)
    {
      case 0: //if start is pressed
        {
          if (mouseX > 150 && mouseX < 250 && mouseY > 475 && mouseY <525)
            {
              screen = 1;
              restart();
              
            }   
          break  
        }
      case 1: //where the player clicks
        {
           
          if(mouseX > 15 && mouseX < (400/3) + 15 && mouseY > 14 && mouseY <(15+(400-70)/3)) // 0,0
              gameUpdate(0,0);
          else if(mouseX > (400/3) + 15 && mouseX < (400/3)*2 && mouseY > 14 && mouseY <(15+(400-70)/3)) //0,1
            gameUpdate(0,1);
          else if(mouseX > (400/3)*2 && mouseX< 400-15 && mouseY > 14 && mouseY <(15+(400-70)/3)) //0,2
            gameUpdate(0,2);
          
          
          else if (mouseX > 15 && mouseX < (400/3) + 15 && mouseY < (15+(400-70)/3)*2 && mouseY >(15+(400-70)/3))
            gameUpdate(1,0);
          else if (mouseX > (400/3) + 15 && mouseX < (400/3)*2  && mouseY < (15+(400-70)/3)*2 && mouseY >(15+(400-70)/3))
            gameUpdate(1,1);
          else if (mouseX > (400/3)*2 && mouseX< 400-15  && mouseY < (15+(400-70)/3)*2 && mouseY >(15+(400-70)/3))
            gameUpdate(1,2);
          
          else if (mouseX > 15 && mouseX < (400/3) + 15 && mouseY > (15+(400-70)/3)*2 && mouseY < 385)
            gameUpdate(2,0);
          else if (mouseX > (400/3) + 15 && mouseX < (400/3)*2  && mouseY > (15+(400-70)/3)*2 && mouseY < 385)
            gameUpdate(2,1);
          else if (mouseX > (400/3)*2 && mouseX< 400-15  && mouseY > (15+(400-70)/3)*2 && mouseY < 385)
            gameUpdate(2,2);
          break;
          
        }
      case 2: //if the player clicks restart
          {
            if(mouseX > 150 && mouseX < 250 && mouseY > 475 && mouseY <525)
              restart();
          }
    }
  
}

        
function gameUpdate(y,x) 
  {
    
    if(gameBoard[y][x] == 0) //sets the value of the array to be equal to the player who's turn it is 
      {
        gameBoard[y][x] = pTurn;
        turnCount++; 
        
        if(pTurn == 1)
          {
            pTurn = 2;
          }
        else
          {
            pTurn = 1;
          }
      }
   
    //checking to see if there are any winners
    
    if(gameBoard[0][0] == gameBoard[0][1] && gameBoard[0][1] == gameBoard[0][2] && gameBoard[0][0] != 0)   // row 1
      {
        let w = gameBoard[0][0];
        win(w);
      }
    else if(gameBoard[1][0] == gameBoard[1][1] && gameBoard[1][1] == gameBoard[1][2] && gameBoard[1][0] != 0) // row 2
      {
        let w = gameBoard[1][0];
        win(w);
      }
    else if(gameBoard[2][0] == gameBoard[2][1] && gameBoard[2][1] == gameBoard[2][2] && gameBoard[2][0] != 0) // row 3
      {
        let w = gameBoard[2][0];
        win(w);
      }
    else if(gameBoard[0][0] == gameBoard[1][0] && gameBoard[1][0] == gameBoard[2][0] && gameBoard[0][0] != 0) // col 1
      {
        let w = gameBoard[0][0];
        win(w);
      }
    else if(gameBoard[0][1] == gameBoard[1][1] && gameBoard[1][1] == gameBoard[2][1] && gameBoard[0][1] != 0) // col 2
      {
        let w = gameBoard[0][1];
        win(w);
      }
    else if(gameBoard[0][2] == gameBoard[1][2] && gameBoard[1][2] == gameBoard[2][2] && gameBoard[0][2] != 0) // col 3
      {
        let w = gameBoard[0][2];
        win(w);
      }
    else if(gameBoard[0][0] == gameBoard[1][1] && gameBoard[1][1] == gameBoard[2][2] && gameBoard[0][0] != 0) // diag 1
      {
        let w = gameBoard[0][0];
        win(w);
      }
    else if(gameBoard[0][2] == gameBoard[1][1] && gameBoard[1][1] == gameBoard[2][0] && gameBoard[0][2] != 0) // diag 2
      {
        let w = gameBoard[0][2];
        win(w);
      }
    else if(turnCount ==9)
      {
        win(0);
      }


    //background(x*30,y*30,y+x*30);
    
    
  }

function restart()
  {
    for(let i=0; i<3; i++) // resets everything to default
    {
      for(let j=0; j<3; j++)
        {
          gameBoard[i][j] = 0;
        }
    }
    
    turnCount = 0;
    screen =1;
    
  }
  
  
function win(w) //funtion is called when game ends
  {
    screen =2;
    turnCount = 0;
    background(10,60,100);
    let t ="";
    switch(w)
      {
        case 0: //if tie
          {
            t = "No Winners!"
            break;
          }
        case 1: //if p1 wins
          {
            t = "P1 Wins!"
            p1Score +=1;
            pTurn =2;
            break;
            
          }
        case 2: //if p2 wins
          {
            t = "P2 Wins!"
            p2Score +=1;
            pTurn =1;
            break;
          }
      }
    
    textSize(60);
    textAlign(CENTER);
    fill(255);
    text(t,200,250);
    textSize(20);
    rect(200,500,100,50);
    fill(0);
    text("restart",200,505);
    
    
  }
function board() //displays the board
{
  
  strokeWeight(2);
  
  line((400/3) + 15,35,(400/3)+15,400-35);
  line((400/3)*2,35,(400/3)*2,400-35);
  
  line(35,(15+(400-70)/3),400-35,15+(400-70)/3);
  line(35,(15+(400-70)/3)*2,400-35,(15+(400-70)/3)*2);
  
  for(let i=0; i<3; i++)
    {
      for(let j=0; j<3; j++)
        {
          if(gameBoard[i][j] === 1)
            {
              fill(0,30,100);
              square(((1+j)*120)-35,100*(1+i) -15,50);
              fill(255);
            }
          if(gameBoard[i][j] === 2)
            {
              fill(100,30,0);
              circle(((1+j)*120)-35,100*(1+i) -15,50);
              fill(255);
            }
        }
    }
  
  if(pTurn == 1)
    {
      textAlign(CENTER);
      fill(0,30,100);
      textSize(40);
      text("P1's Turn",200,450);
      fill(0);
    }
  else
    {
      textAlign(CENTER);
      fill(100,30,0);
      textSize(40);
      text("P2's Turn",200,450);
      fill(0);
    }
  
  textSize(20);
  text("p1 score: " + p1Score + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tp2 score: " + p2Score, 200,550);
  

  
  
}
  
function mainMenu() //main menu
  {
    background(10,60,100); 
    textSize(60);
    textAlign(CENTER);
    fill(255);
    text("TikTakToe",200,250);
    textSize(20);
    rect(200,500,100,50);
    fill(0);
    text("Start",200,505);
  }